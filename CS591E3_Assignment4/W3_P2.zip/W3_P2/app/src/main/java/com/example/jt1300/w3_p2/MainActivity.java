package com.example.jt1300.w3_p2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.graphics.Point;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    TextView sbl;
    TextView tip;
    TextView total;
    EditText amount;
    SeekBar bar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sbl = findViewById(R.id.sblabel);  //seek bar label
        tip = findViewById(R.id.tnew);  //tip to be calculated.
        total = findViewById(R.id.ttnew); //Total to be calculated
        amount = findViewById(R.id.bill); //bill amount entered by user.
        bar = findViewById(R.id.sb);
        bar.setMax(25);
        bar.setProgress(0);

        amount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String temp = amount.getText().toString();
                if(temp.compareTo("") == 0){
                    total.setText("$0.00");
                    tip.setText("$0.00");
                } else{
                    double t1 = Double.valueOf(temp);
                    total.setText(temp);
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String temp = amount.getText().toString();
                if(temp.compareTo("") == 0){
                    total.setText("$0.00");
                    tip.setText("$0.00");
                } else{
                    double t1 = Double.valueOf(temp);
                    total.setText(temp);
                }
            }
        });

        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int progress; //tracks seekbar changes
            double percent; //double representing the tip percentage
            double ttip; //calculated tip
            double ttl; //calculated total

            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                progress = i;
                sbl.setText(String.valueOf(progress) + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                sbl.setText(String.valueOf(progress) + "%");
                String temp = amount.getText().toString();
                if(temp.compareTo("") == 0){

                } else {
                    double temp2 = Double.valueOf(temp);
                    percent = progress / 100.00;
                    ttip = Math.round((temp2 * percent) *100)/100.00;
                    ttl = Math.round((ttip + temp2) * 100)/100.00;
                    tip.setText(String.valueOf(ttip));
                    total.setText(String.valueOf(ttl));
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                sbl.setText(String.valueOf(progress) + "%");
                String temp = amount.getText().toString();
                if(temp.compareTo("") == 0){

                } else {
                    double temp2 = Double.valueOf(temp);
                    percent = progress / 100.00;
                    ttip = Math.round((temp2 * percent) *100)/100.00;
                    ttl = Math.round((ttip + temp2) * 100)/100.00;
                    tip.setText(String.valueOf(ttip));
                    total.setText(String.valueOf(ttl));
                }

            }
        });
    }

}
