package com.example.reda.chapter7_p28;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnTouchListener{

    private TextView tv;
    private RelativeLayout.LayoutParams params;
    private RelativeLayout rl;
    private int startX;
    private int startY;
    private int startTouchX;
    private int startTouchY;
    private static int startWidth;
    private static int startHeight;

    private GestureDetector gestureDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildGuiByCode();
        gestureDetector = new GestureDetector(this, new GestureListener());
    }

    public void buildGuiByCode(){
        tv = new TextView(this);
        tv.setBackgroundColor(0xFFFF0000);
        tv.setGravity(Gravity.CENTER);

        rl = new RelativeLayout(this);
        params = new RelativeLayout.LayoutParams(300,200);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        startHeight = displayMetrics.heightPixels;
        startWidth = displayMetrics.widthPixels;
        Log.d("THE HEIGHT IS", Integer.toString(startHeight));
        params.leftMargin = (startWidth/2) - 150;
        params.topMargin = (startHeight/2)-160;

        rl.addView(tv,params);
        setContentView(rl);

        tv.setOnTouchListener(this);

    }

    @Override
    public boolean onTouchEvent(MotionEvent event){
        this.gestureDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

    public boolean onTouch(View v, MotionEvent event){
        int action = event.getAction();
        switch(action){
            case MotionEvent.ACTION_DOWN:
                startX = params.leftMargin;
                startY = params.rightMargin;
                startTouchX = (int) event.getX();
                startTouchY = (int) event.getY();
                break;

            case MotionEvent.ACTION_MOVE:
                params.leftMargin = startX + (int) event.getX() - startTouchX;
                params.topMargin = startY + (int) event.getY() - startTouchY;
                tv.setLayoutParams(params);
                break;

        }
        return true;
    }

    private void onFlingAction(){
        Random rand = new Random();
        int newWidth = rand.nextInt(startWidth);
        int newHeight = rand.nextInt(startHeight);

        while ((newWidth + 300) >= startWidth)
            newWidth = rand.nextInt(startWidth);

        while ((newHeight + 160 + 200) >= startHeight)
            newHeight = rand.nextInt(startHeight);
        params.leftMargin = newWidth;
        params.topMargin = newHeight;


        rl.addView(tv,params);
        setContentView(rl);
    }


    public class GestureListener extends GestureDetector.SimpleOnGestureListener{
        private static final int SWIPE_THRESHOLD = 100;
        private static final int SWIPE_VELOCITY_THRESHOLD = 100;

        @Override
        public boolean onDown(MotionEvent e) {
            return true;
        }

        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            boolean result = false;
            try {
                float diffY = e2.getY() - e1.getY();
                float diffX = e2.getX() - e1.getX();
                if (Math.abs(diffX) > Math.abs(diffY)) {
                    if (Math.abs(diffX) > SWIPE_THRESHOLD && Math.abs(velocityX) > SWIPE_VELOCITY_THRESHOLD) {
                        if (diffX > 0) {
                            onFlingAction();
                        } else {
                            onFlingAction();
                        }
                        result = true;
                    }
                }
                else if (Math.abs(diffY) > SWIPE_THRESHOLD && Math.abs(velocityY) > SWIPE_VELOCITY_THRESHOLD) {
                    if (diffY > 0) {
                        onFlingAction();
                    } else {
                        onFlingAction();
                    }
                    result = true;
                }
            } catch (Exception exception) {
                exception.printStackTrace();
            }
            return result;
        }

    }
}

