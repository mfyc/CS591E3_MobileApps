package com.cs591.w4_p2;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class XActivity extends AppCompatActivity {

    String url;
    WebView wvBrowser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_x);

        Intent intent1 = getIntent();
        url = intent1.getStringExtra("url");

        wvBrowser = (WebView) findViewById(R.id.wvBrowser);

        wvBrowser.loadUrl(url);

    }
}
