package com.cs591.w4_p2;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.SeekBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private String TAG = "ACCEL";

    private SeekBar sbAccel;

    private float acceleration;
    private float currentAcceleration;
    private float lastAcceleration;
    private float lastX, lastY, lastZ;

    private static int SIGNIFICANT_SHAKE = 100000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        acceleration = 0.00f;                                         //Initializing Acceleration data.
        currentAcceleration = SensorManager.GRAVITY_EARTH;            //We live on Earth.
        lastAcceleration = SensorManager.GRAVITY_EARTH;
        setContentView(R.layout.activity_main);

        sbAccel = (SeekBar) findViewById(R.id.sbAccel);

        sbAccel.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                SIGNIFICANT_SHAKE = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        enableAccelerometerListening();
    }

    @Override
    protected void onStop() {
        disableAccelerometerListening();
        super.onStop();
    }

    // enable listening for accelerometer events
    private void enableAccelerometerListening() {
        // The Activity has a SensorManager Reference.
        // This is how we get the reference to the device's SensorManager.
        SensorManager sensorManager =
                (SensorManager) this.getSystemService(
                        Context.SENSOR_SERVICE);    //The last parm specifies the type of Sensor we want to monitor


        //Now that we have a Sensor Handle, let's start "listening" for movement (accelerometer).
        //3 parms, The Listener, Sensor Type (accelerometer), and Sampling Frequency.
        sensorManager.registerListener(sensorEventListener,
                sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                SensorManager.SENSOR_DELAY_NORMAL);   //don't set this too high, otw you will kill user's battery.
    }



    // disable listening for accelerometer events
    private void disableAccelerometerListening() {

//Disabling Sensor Event Listener is two step process.
        //1. Retrieve SensorManager Reference from the activity.
        //2. call unregisterListener to stop listening for sensor events
        //THis will prevent interruptions of other Apps and save battery.

        // get the SensorManager
        SensorManager sensorManager =
                (SensorManager) this.getSystemService(
                        Context.SENSOR_SERVICE);

        // stop listening for accelerometer events
        sensorManager.unregisterListener(sensorEventListener,
                sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER));
    }

    private final SensorEventListener sensorEventListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            // get x, y, and z values for the SensorEvent
            //each time the event fires, we have access to three dimensions.
            //compares these values to previous values to determine how "fast"
            // the device was shaken.
            //Ref: http://developer.android.com/reference/android/hardware/SensorEvent.html

            float x = sensorEvent.values[0];   //always do this first
            float y = sensorEvent.values[1];
            float z = sensorEvent.values[2];

            // save previous acceleration value
            lastAcceleration = currentAcceleration;

            // calculate the current acceleration
            currentAcceleration = x * x + y * y + z * z;   //This is a simplified calculation, to be real we would need time and a square root.

            // calculate the change in acceleration        //Also simplified, but good enough to determine random shaking.
            acceleration = currentAcceleration *  (currentAcceleration - lastAcceleration);

            String url;

            // if the acceleration is above a certain threshold
            if (acceleration > SIGNIFICANT_SHAKE) {
                Log.e(TAG, "SIG SHAKE = " + Integer.toString(SIGNIFICANT_SHAKE));
                Toast.makeText(getApplicationContext(), "Nice shake!",  Toast.LENGTH_LONG).show();
                float deltaX = x - lastX;
                float deltaY = y - lastY;
                float deltaZ = z - lastZ;

                // find largest change in dimension
                if (deltaX > deltaY && deltaX > deltaZ) {
                    // x is greatest; open Google
                    url = "http://google.com";
                    Intent intent = new Intent(MainActivity.this, XActivity.class);
                    intent.putExtra("url", url);
                    startActivity(intent);
                }

                else if (deltaY > deltaX && deltaY > deltaZ) {
                    // y is greatest; open Yahoo
                    Log.e("y", Boolean.toString(x > y && x > z));
                    url = "http://yahoo.com";
                    Intent intent = new Intent(MainActivity.this, XActivity.class);
                    intent.putExtra("url", url);
                    startActivity(intent);
                }

                else if (deltaZ > deltaX && deltaZ > deltaY){
                    // z is greatest; open Bing
                    url = "http://bing.com";
                    Intent intent = new Intent(MainActivity.this, XActivity.class);
                    intent.putExtra("url", url);
                    startActivity(intent);
                }
            }

            lastX = x;
            lastY = y;
            lastZ = z;

        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }
    };

}
