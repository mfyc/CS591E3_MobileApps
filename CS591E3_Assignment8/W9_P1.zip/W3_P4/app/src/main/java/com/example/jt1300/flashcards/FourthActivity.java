package com.example.jt1300.flashcards;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by Jt1300 on 4/12/18.
 */

public class FourthActivity extends AppCompatActivity{

    //Arrays and TextViews
    public static TextView u1;
    public static TextView u2;
    public static TextView u3;
    public static TextView u4;
    public static TextView u5;
    public static TextView p1;
    public static TextView p2;
    public static TextView p3;
    public static TextView p4;
    public static TextView p5;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        u1 = (TextView) findViewById(R.id.u1);
        u2 = (TextView) findViewById(R.id.u2);
        u3 = (TextView) findViewById(R.id.u3);
        u4 = (TextView) findViewById(R.id.u4);
        u5 = (TextView) findViewById(R.id.u5);
        p1 = (TextView) findViewById(R.id.u1p);
        p2 = (TextView) findViewById(R.id.u2p);
        p3 = (TextView) findViewById(R.id.u3p);
        p4 = (TextView) findViewById(R.id.u4p);
        p5 = (TextView) findViewById(R.id.u5p);
        final Bundle bundle = getIntent().getExtras();
        final String username = bundle.getString("User");
        Button btn = (Button)findViewById(R.id.play);

        //play again button
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), SecondActivity.class);
                if(bundle.containsKey("flag")){
                    boolean flag = bundle.getBoolean("flag");
                    i.putExtra("flag", flag);
                }
                i.putExtra("User", username);
                startActivity(i);
            }
        });
        //get scores to display
        getscores();

        Button btn2 = (Button)findViewById(R.id.logout);
        //logout
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
            }
        });
    }

    //get top scores to display
    public void getscores(){
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Tests");
        final ArrayList<Double> scores = new ArrayList<>();
        final ArrayList<String> users = new ArrayList<>();
        final HashMap<String, Double> tmap = new HashMap<>();
        //read from database
        myRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                String s2 = String.valueOf(dataSnapshot.getValue());
                String s1 = String.valueOf(dataSnapshot.getKey());
                users.add(s1);
                scores.add(Double.valueOf(s2));
                tmap.put(s1, Double.valueOf(s2));
                //with data, get top 5 users
                top5(users, scores, tmap);
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    //display updated top 5
    public void top5(ArrayList<String> users, ArrayList<Double> scores, HashMap<String, Double> map) {
        //scores
        Collections.sort(scores, Collections.<Double>reverseOrder());
        Map<String, Double> map1 = sortByValues(map);
        Set set = map1.entrySet();
        Iterator it = set.iterator();

        int count = 0;
        ArrayList<String> t2users = new ArrayList<>();
        //check if there are 5 or more users
        if (users.size() >= 5) {
            //get top 5 names matched with score
            while(it.hasNext()){
                Map.Entry<String, Double> me2 = (Map.Entry)it.next();
                String u = me2.getKey();
                t2users.add(u);
            }
            Collections.reverse(t2users);
            //display results
            u1.setText(t2users.get(0));
            u2.setText(t2users.get(1));
            u3.setText(t2users.get(2));
            u4.setText(t2users.get(3));
            u5.setText(t2users.get(4));
            p1.setText(String.valueOf(scores.get(0)));
            p2.setText(String.valueOf(scores.get(1)));
            p3.setText(String.valueOf(scores.get(2)));
            p4.setText(String.valueOf(scores.get(3)));
            p5.setText(String.valueOf(scores.get(4)));

        } else {
            //get top 5 names matched with score
            while(it.hasNext()){
                    Map.Entry<String, Double> me2 = (Map.Entry)it.next();
                    String u = me2.getKey();
                    t2users.add(u);
            }
            Collections.reverse(t2users);

            //check how many users and display
            if (map1.size() == 1) {
                u1.setText(t2users.get(0));
                p1.setText(String.valueOf(scores.get(0)));
            }

            if (map1.size() == 2) {
                u1.setText(t2users.get(0));
                u2.setText(t2users.get(1));
                p1.setText(String.valueOf(scores.get(0)));
                p2.setText(String.valueOf(scores.get(1)));
            }

            if (map1.size() == 3) {
                u1.setText(t2users.get(0));
                u2.setText(t2users.get(1));
                u3.setText(t2users.get(2));
                p1.setText(String.valueOf(scores.get(0)));
                p2.setText(String.valueOf(scores.get(1)));
                p3.setText(String.valueOf(scores.get(2)));
            }

            if (map1.size() == 4) {
                u1.setText(t2users.get(0));
                u2.setText(t2users.get(1));
                u3.setText(t2users.get(2));
                u4.setText(t2users.get(3));
                p1.setText(String.valueOf(scores.get(0)));
                p2.setText(String.valueOf(scores.get(1)));
                p3.setText(String.valueOf(scores.get(2)));
                p4.setText(String.valueOf(scores.get(3)));
            }
        }
    }

    //custom comparator to sort hashmap values
    private static HashMap sortByValues(HashMap map) {
        List list = new LinkedList(map.entrySet());

        Collections.sort(list, new Comparator() {
            public int compare(Object o1, Object o2) {
                return ((Comparable) ((Map.Entry) (o1)).getValue())
                        .compareTo(((Map.Entry) (o2)).getValue());
            }
        });

        HashMap sortedHashMap = new LinkedHashMap();
        for (Iterator it = list.iterator(); it.hasNext();) {
            Map.Entry entry = (Map.Entry) it.next();
            sortedHashMap.put(entry.getKey(), entry.getValue());
        }
        return sortedHashMap;
    }
}
