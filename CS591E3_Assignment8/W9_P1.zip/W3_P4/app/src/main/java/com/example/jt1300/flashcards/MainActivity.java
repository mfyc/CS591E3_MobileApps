package com.example.jt1300.flashcards;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.Iterator;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    public static boolean flag = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //view content
        Button btn = findViewById(R.id.submit);
        Button btn2 = findViewById(R.id.register);

        //onclick listeners
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText n1 = findViewById(R.id.user);
                EditText n2 = findViewById(R.id.pass);
                final String s1 = n1.getText().toString();
                final String s2 = n2.getText().toString();
                if(verify(s1, s2)){
                    Intent main = new Intent(getApplicationContext(), FourthActivity.class);
                    main.putExtra("User", s1);
                    startActivity(main);
                } else{
                    Context context = getApplicationContext();
                    int duration = Toast.LENGTH_LONG;
                    Toast.makeText(context, "Invalid Username or Password combination", duration).show();
                }
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent main = new Intent(getApplicationContext(), ThirdActivity.class);
                startActivity(main);
            }
        });
    }

    //verify credentials with database
    public static boolean verify(String usr, String pass) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("User");
        final String user = usr;
        final String pw = pass;
        myRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                Map<String, Object> map = (Map<String, Object>)dataSnapshot.getValue();
                String s1 = String.valueOf(dataSnapshot.getKey());
                Iterator it = map.entrySet().iterator();
                String s2 = String.valueOf(it.next());
                if(s1.compareTo(user) == 0 && ("password="+pw).compareTo(s2) == 0){
                    flag = true;
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        return flag;
    }
}
