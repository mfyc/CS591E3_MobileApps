package com.example.jt1300.flashcards;

/**
 * Created by Jt1300 on 2/11/18.
 */

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.Random;

public class SecondActivity extends AppCompatActivity{
    private int counter = 0;
    private int correct = 0;
    private EditText answer;
    private TextView num1;
    private TextView num2;
    public static String secretMsg;
    public static String score = "0";
    public static boolean flag = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        //view content
        answer = findViewById(R.id.ans);
        num1 = findViewById(R.id.num1);
        num2 = findViewById(R.id.num2);
        Button btn = findViewById(R.id.replay);
        Button btn1 = findViewById(R.id.topfive);
        Button btn2 = findViewById(R.id.next);

        //get bundle information
        Context context = getApplicationContext();
        Bundle bundle = getIntent().getExtras();
        if(bundle.containsKey("User")){
            secretMsg = bundle.getString("User");
        }
        if(bundle.containsKey("flag")){
            flag = bundle.getBoolean("flag");
        }

        //welcome user
        int duration = Toast.LENGTH_SHORT;
        Toast.makeText(context, "Welcome " + secretMsg, duration).show();

        //hide buttons
        btn.setVisibility(View.GONE);
        btn1.setVisibility(View.GONE);

        //onclick listener for next problem
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Next(view);
            }
        });

        //setup first problem
        Random rand = new Random();
        int q = rand.nextInt(100) + 1;
        int d = rand.nextInt(q/2 + 1) + 1;
        boolean f2 = true;
        if(q % d != 0){
            f2 = false;
        }
        if(!f2){
            while(q % d != 0){
                q = rand.nextInt(100) + 1;
                d = rand.nextInt(q/2 + 1) + 1;
            }
        }
        num1.setText(String.valueOf(q));
        num2.setText(String.valueOf(d));
        counter++;

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString("answer", answer.getText().toString());
        outState.putString("num1", num1.getText().toString());
        outState.putString("num2", num2.getText().toString());
        super.onSaveInstanceState(outState);

    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        answer.setText(savedInstanceState.getString("answer"));
        num1.setText(savedInstanceState.getString("num1"));
        num2.setText(savedInstanceState.getString("num2"));

    }

    //get the next problem
    public void Next(View v){
        if(counter == 11){

            //display score, play again and restart
            Context context = getApplicationContext();
            int duration = Toast.LENGTH_LONG;
            Toast.makeText(context, "Results: " + String.valueOf(correct) + " out of 10", duration).show();
            restart();

            //hide the keyboard
            InputMethodManager imm = (InputMethodManager) this.getSystemService(this.INPUT_METHOD_SERVICE);
            View view = this.getCurrentFocus();
            if (view == null) {
                view = new View(this);
            }
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        } else{
            //get next problem
            boolean f1 = confirm(num1.getText().toString(), num2.getText().toString());
            String bool = String.valueOf(f1);
            if (f1){
                correct++;
            }
            Random rand = new Random();
            int q = rand.nextInt(100) + 1;
            int d = rand.nextInt(q/2 + 1) + 1;
            boolean f2 = true;
            if(q % d != 0){
                f2 = false;
            }
            if(!f2){
                while(q % d != 0){
                    q = rand.nextInt(100) + 1;
                    d = rand.nextInt(q/2 + 1) + 1;
                }
            }
            num1.setText(String.valueOf(q));
            num2.setText(String.valueOf(d));
            answer.setText("");
            counter++;
        }
    }
    //validate the given asnwer
    public boolean confirm(String s1, String s2){
        int temp = Integer.parseInt(s1);
        int temp2 = Integer.parseInt(s2);
        int temp3 = Integer.parseInt(answer.getText().toString());
        if(temp/temp2 == temp3){
            return true;
        }
        else{
            return false;
        }
    }
    //restart the game and or check for top 5 users.
    public void restart(){
        //hide and display new buttons
        Button btn = findViewById(R.id.replay);
        btn.setVisibility(View.VISIBLE);
        Button btn2 = findViewById(R.id.next);
        btn2.setVisibility(View.INVISIBLE);
        Button btn1 = findViewById(R.id.topfive);
        btn1.setVisibility((View.VISIBLE));

        //update users new score
        Insert(secretMsg, correct);

        //onclick listeners for navigation
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent restart = getIntent();
                restart.putExtra("User", secretMsg);
                restart.putExtra("flag", flag);
                finish();
                startActivity(restart);

            }
        });

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                Intent i = new Intent(getBaseContext(), FourthActivity.class);
                i.putExtra("User", secretMsg);
                i.putExtra("flag", flag);
                startActivity(i);
            }
        });
    }

    //insert data into database
    public void Insert(String user, Integer correct) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference myRef = database.getReference("Tests");
        final String user1 = user;
        final int right = correct;
        //get test data from database
        myRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                String s2 = String.valueOf(dataSnapshot.getValue());
                String s1 = String.valueOf(dataSnapshot.getKey());
                //if the user matches, recalculate their overall score. If it's their first test, just replace the old score.
                if(s1.compareTo(user1) == 0){
                    score = s2;
                    double temp = Double.valueOf(score);
                    if(flag) {
                        double percent = (right / 10);
                        myRef.child(user1).setValue(String.valueOf(percent));
                        flag = false;
                    } else {
                        double percent = (temp + (right / 10))/2;
                        myRef.child(user1).setValue(String.valueOf(percent));
                    }
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }
}
