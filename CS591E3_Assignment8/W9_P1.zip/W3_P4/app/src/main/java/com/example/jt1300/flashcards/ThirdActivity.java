package com.example.jt1300.flashcards;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Created by Jt1300 on 4/11/18.
 */

public class ThirdActivity extends AppCompatActivity {

    public static boolean flag;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        //view content
        Button submit = (Button) findViewById(R.id.rsubmit);
        final EditText reusr = (EditText) findViewById(R.id.reuser);
        final EditText repass = (EditText) findViewById(R.id.repass);

        //onclick listener
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp1 = reusr.getText().toString();
                String temp2 = repass.getText().toString();
                //insert credentials into database
                if (Insert(temp1, temp2)) {
                    Intent i = new Intent(getBaseContext(), FourthActivity.class);
                    i.putExtra("User", temp1);
                    i.putExtra("flag", true);
                    startActivity(i);
                } else {
                    Context context = getApplicationContext();
                    int duration = Toast.LENGTH_LONG;
                    Toast.makeText(context, "Username already exists", duration);
                }
            }
        });

    }

    //insert information into database
    public boolean Insert(String usr, String password) {
        flag = true;
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        final String user = usr;
        myRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                String s1 = String.valueOf(dataSnapshot.getKey());
                if(s1.compareTo(user) == 0){
                    flag = false;
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        if(flag){
            myRef.child("User").child(usr).child("password").setValue(password);
            myRef.child("Tests").child(usr).setValue("0.0");
        }
        return flag;

    }

}


